KINGS DRAFT ITALIA v0.6.1

Aggiornamenti:
- Database completo Split 2 con 150 giocatori e overall concordati.
- Gear7 FC sostituisce D-POWER.
- Forza squadre: Alpak 90, Underdogs 89, Stallions 88, FC Caesar 88, BIGBRO 87, TRM 87, Gear7 86, Boomers 85, Zebras 85, Circus 84, Zeta Como 83.
- Nessun pareggio: in caso di parità la partita viene risolta agli shootout.

Aprire tramite server locale o pubblicazione web, perché i file JSON vengono caricati con fetch().
